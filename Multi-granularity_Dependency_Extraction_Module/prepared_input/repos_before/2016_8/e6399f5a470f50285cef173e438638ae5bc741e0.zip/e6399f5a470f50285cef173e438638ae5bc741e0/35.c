/bug00084
/bug00247
/bug00247a
/bug00248
/bug00248a
/tga_null
/tga_read
