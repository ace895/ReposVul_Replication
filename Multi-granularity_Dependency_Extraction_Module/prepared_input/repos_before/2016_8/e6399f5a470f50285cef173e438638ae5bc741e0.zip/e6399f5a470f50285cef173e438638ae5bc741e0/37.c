libgd_test_programs += \
	tga/bug00084 \
	tga/bug00247 \
	tga/bug00247a \
	tga/bug00248 \
	tga/bug00248a \
	tga/heap_overflow \
	tga/tga_null \
	tga/tga_read

EXTRA_DIST += \
	tga/CMakeLists.txt \
	tga/bug00084.tga \
	tga/bug00247.tga \
	tga/bug00247a.tga \
	tga/bug00248.tga \
	tga/bug00248a.tga \
	tga/heap_overflow_1.tga \
	tga/heap_overflow_2.tga \
	tga/tga_read_rgb.png \
	tga/tga_read_rgb.tga \
	tga/tga_read_rgb_rle.tga
