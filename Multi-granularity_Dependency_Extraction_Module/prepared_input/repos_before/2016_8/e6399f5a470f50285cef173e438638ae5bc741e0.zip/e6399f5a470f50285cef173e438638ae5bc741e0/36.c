LIST(APPEND TESTS_FILES
	tga_null
	bug00084
	bug00247
	bug00247a
	bug00248
	bug00248a
	heap_overflow
	tga_read
)

ADD_GD_TESTS()
